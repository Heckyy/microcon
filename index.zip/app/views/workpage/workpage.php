<!-- Fully Dedicated To -->
<section id="fully-dedicated-to">
    <div class="container">
        <div class="row ms-0">
            <div class="col-12 col-lg-7 py-0 py-lg-5">
                <div class="title-fully-dedicated-to">Fully dedicated to</div>
                <div class="subtitle-fully-dedicated-to">
                    Micro, Small and Medium Enterprises to
                    achieve success in the digital era.
                </div>
                <button class="btn btn-home col-12 col-lg-3" width="120px" height="32px" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    Let's Talk
                </button>
            </div>
            <div class="col-12 col-lg-5 ">
                <img src="<?= BASE_URL; ?>/assets/img/Groupwork.svg" class="img-fluid" />
            </div>
        </div>
    </div>
</section>
<!--  End Of Fully Dedicated To -->

